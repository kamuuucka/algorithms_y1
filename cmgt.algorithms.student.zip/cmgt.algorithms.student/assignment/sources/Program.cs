using System;

class Program
{
    public static void Main(String[] args)
    {
            AlgorithmsAssignment dcg = new AlgorithmsAssignment();
            dcg.Start();
    }
}
